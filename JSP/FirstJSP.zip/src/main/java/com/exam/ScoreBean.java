package com.exam;

public class ScoreBean {
	private String name;
	private int Korean;
	private int English;
	private int Math;

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public int getKorean() {
		return Korean;
	}
	public void setKorean(int korean) {
		this.Korean = korean;
	}
	
	public int getEnglish() {
		return English;
	}
	public void setEnglish(int english) {
		this.English = english;
	}
	
	public int getMath() {
		return Math;
	}
	public void setMath(int math) {
		this.Math = math;
	}
	
	public int getTotal() {
		return (Korean + English + Math);
	}
	public int getAvg() {
		return((Korean + English + Math)/3);
	}
	public String getGrade() {
		String grade = "";
		switch(getAvg()/10){
		case 10:
		case 9 : grade="A";break;
		case 8 : grade = "B"; break;
		case 7 : grade = "C"; break;
		default : grade = "F";
		}
		return grade;
	}
}

