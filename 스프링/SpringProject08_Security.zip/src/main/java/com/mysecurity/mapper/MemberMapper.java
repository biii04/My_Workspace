package com.mysecurity.mapper;

import com.mysecurity.dto.MemberDTO;

public interface MemberMapper {
	public MemberDTO read(String userid);
}
