package com.myboard.myapp07;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.myboard.dto.BoardDTO;
import com.myboard.dto.PageVO;
import com.myboard.model.BoardService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	@Autowired
	private BoardService service;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
//	@RequestMapping(value = "/", method = RequestMethod.GET)
//	public String home(Locale locale, Model model) {
			
//		return "boardInsert";
//	}

	@GetMapping({"/", "list"})
	public String list(Model model, String pageNum,
			@RequestParam(name="field", defaultValue="")String field,  //처음엔 field와 word값이 없기 때문에 defaultValue에 공백을 줌
			@RequestParam(name="word", defaultValue="")String word) {
		int currentPage = pageNum == null?1 : Integer.parseInt(pageNum);  //pagenum이 null이면 1, 아니면 pagenum
		int pageSize = 5;  //한 화면에 5개 보이게
		
		
		HashMap<String, Object> hm = new HashMap<String, Object>(); //페이징 처리 때문에 string, string이 아니라 string object(최상위)로 한것.
		hm.put("field", field);
		hm.put("word", word);
		hm.put("pageStart", (currentPage-1)*pageSize);
		hm.put("pageSize", pageSize);
		
		List<BoardDTO> boards = service.findAll(hm);
		int count = service.getCount(hm);
		PageVO page=new PageVO(count, currentPage, pageSize);
		page.setField(field);
		page.setWord(word);  //검색했을때도 페이징 가능하게 함
		
		model.addAttribute("rowNo", count-((currentPage-1)*pageSize));  //글 순서
		model.addAttribute("boards", boards);
		model.addAttribute("count", count);
		model.addAttribute("p", page);
		
		return "boardList";
	}
	
	@GetMapping("insert")
	public String insert(HttpSession session) {
		if(session.getAttribute("sMember")==null) {
			return "member/login";
		}
		return "boardInsert";
	}
	
	@PostMapping("insert")
	public String insert(BoardDTO board) {
		service.insert(board);
		return "redirect:list";
	}
	
	//상세보기
	@GetMapping("view/{num}")
	public String view(@PathVariable  int num , Model model) {
		BoardDTO board = service.findByNum(num);
		model.addAttribute("board", board);
		return "view";
	}
	
	//삭제
	@DeleteMapping("delete/{num}")
	@ResponseBody
	public String delete(@PathVariable int num) {
		service.delete(num);
		return "success";
	}
	//수정폼
	@GetMapping("update/{num}")
	public String update(@PathVariable int num, Model model) {
		 BoardDTO board =   service.findByNum(num);
		 model.addAttribute("board", board);
		return "update";
	}
	
	//수정
	@PutMapping("update")
	@ResponseBody
	public String update(@RequestBody BoardDTO board) {
		service.update(board);
		return "success";
	}
	
//	@GetMapping("delete/{num}")
//	public String delete(@PathVariable int num) {
//		bserivce.delete(num);
//		
//		return "redirect:/list";
//	}
	
}
