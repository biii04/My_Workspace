package com.myboard.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape; 


public class CommentDTO {
	private int cnum;
	private String userid;
	private String content;
	@JsonFormat(shape=Shape.STRING, pattern="yyyy-MM-dd",timezone="Asia/Seoul") //�ð��� �����Բ� ����
	private Date regdate;
	private int bnum;  //board���̺��� ���� �ܷ�Ű
	
	//getter, setter
	public int getCnum() {
		return cnum;
	}
	public void setCnum(int cnum) {
		this.cnum = cnum;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	public int getBnum() {
		return bnum;
	}
	public void setBnum(int bnum) {
		this.bnum = bnum;
	}
	
	
}
