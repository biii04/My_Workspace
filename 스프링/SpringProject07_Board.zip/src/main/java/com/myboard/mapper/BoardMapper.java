package com.myboard.mapper;

import java.util.HashMap;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.myboard.dto.BoardDTO;
import com.myboard.dto.FileBoardDTO;

public interface BoardMapper {
	
	//�߰�
	@Insert("insert into board(title, writer, content) values(#{title}, #{writer}, #{content})")
	public void insert(BoardDTO board);
	
	//��ü����
	//@Select("select * from board")
	public List<BoardDTO> list(HashMap<String,Object> hm);
	
	
	//count
	//@Select("select count(*) from board")
	public int getCount(HashMap<String, Object> hm);
	
	//�󼼺���
	@Select("select * from board where num = #{num}")
	public BoardDTO findByNum(int num);
	
	//delete
	@Delete("delete from board where num=#{num}")
	public void delete(int num);
	
	//update
	@Update("update board set title=#{title}, content=#{content},regdate=now() where num=#{num}")
	public void update(BoardDTO board);
	
	//��� �� ����
	//@Update("update board set replyCnt = replyCnt+#{amount} where num=#{bnum}")
	public void updateReplyCnt(@Param(value = "bnum") int bnum, @Param(value = "amount") int amount);
	//bnum���� ���°� bnum���� �ް� amount�� ���°� amount�� �޴´�..?
	
	//
	@Update("update board set hitcount=hitcount+1 where num=#{num}")
	public void up_ReadCount(int num);
	
	//���� ���ε� �߰�
	@Insert("insert into fileboard(title, writer, content, fileImage) values(#{title},#{writer},#{content},#{fileImage})")
	public void fileInsert(FileBoardDTO board);
	
	//���� ����Ʈ
	@Select("select * from fileboard")
	public List<FileBoardDTO> fileList();
}
