package utils;

public class Define {

	public static final int KOREAN = 1001;  //����
	public static final int MATH = 2001;    //����
	public static final int DANCE = 3001;   //��۴���
		
	public static final int AB_TYPE = 0;    // A, B, C
	public static final int SAB_TYPE = 1;   // S, A, B, c
	public static final int PF_TYPE = 2;   // P, F
	
}
