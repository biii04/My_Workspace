package generics;

public class Point<T, V> {
	
	
	// Integer T
	// Double V
	
	T x;
	V y;
	
	Point(T x, V y){
		this.x = x;
		this.y = y;
	}
	
	public  T getX() {
			return x;  //증거값을 남김 x type은 integer getx라는 메소드로 호출해서 return 즉, integer로 반환한다는걸 알 슈 있음
	}

	public V getY() {
		return y;
    }
}
