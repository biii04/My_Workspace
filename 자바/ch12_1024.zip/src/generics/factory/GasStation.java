package generics.factory;

public class GasStation {

}
