package blog;

public class blog {

}
