package Map;

public class WeaponStore extends Map {
	
	int commonSword = 500;
	int commonBow = 500;
	int normalSword = 5000;
	int normalBow = 5000;
	
	
	public int show(int money, int num) {
		
		name = "무기 상점";
		System.out.println(name + "에서 물건을 구매 시도하는 중입니다.");
		
		if(num == 1) {
			if(commonSword <= money) {
				return money - commonSword;
			}
		}
		
		if(num == 2) {
			if(commonBow <= money) {
				return money - commonBow;
			}
		}
		
		if(num == 3) {
			if(normalSword <= money) {
				return money - normalSword;
			}
		}
		
		if(num == 4) {
			if(normalBow <= money) {
				return money - normalBow;
			}
		}
		
		return money;
	}
}

