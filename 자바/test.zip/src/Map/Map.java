package Map;

public class Map {
	
	String  name;
}
