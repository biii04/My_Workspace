package lotto;

public class lotto {
	public static void main(String[]args) {
		int lotto[] = new int[6];
		
		for(int i = 0; i<6; i++) {
			lotto[i] = (int)(Math.random()*46) +1;  // 1~46까지 랜덤출력
			
			for(int j=0; j<i; j++) {  // 중복방지
				if(lotto[i] == lotto[j]) {
					i--;
					break;
				}
			}
		}
		System.out.println("로또번호 : ");
		
		for(int i = 0; i<6; i++) {
			System.out.println(lotto[i] + " ");
		}
	}
}