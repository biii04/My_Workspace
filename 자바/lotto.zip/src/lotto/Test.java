package lotto;

public class Test{
    public static void exam(){
       int x = 10;
       int y = 2;
       int z = 2;
       z=++x/y;
       System.out.println(x);
       System.out.println(y);
       System.out.println(z);
    
//    System.out.println(x*=y+1);
//    System.out.println(z=++x+y++);
    }
    public static void main(String [] args){
       exam();
    }
}