package lotto;

public class St {

}
