package interfaceex;

public interface Y {

	void y();
}
