package bookshelf;

import java.util.ArrayList;

public class Shelf {

	protected ArrayList<String> shelf;  //shelf 타입은 array(여러개 담을 수 있는 배열)_컬랙션
	
	public Shelf(){
		shelf = new ArrayList<String>();
	}
	
	public ArrayList<String> getShelf(){
		return shelf;
	}
	
	public int getCount(){
		return shelf.size();
	}
}
