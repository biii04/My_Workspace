package scheduler;

public interface Scheduler {

	// 추상 메서드로 전환됨
	public void getNextCall();
	public void sendCallToAgent();
	
}
