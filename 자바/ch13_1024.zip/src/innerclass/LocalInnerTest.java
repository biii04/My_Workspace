package innerclass;


class Outer{
	
	int outNum = 100;
	static int sNum = 200;
	
		//getRunnable는 메서드 이름이고, 매개변수로 i라는 변수를 입력값으로 본다
	// getRunnable 메서드를 호출하면 결과 값이 참조형 변수로 나온다. 결과값의 타입은 인터페이스형.Runnable
	// new MyRunnable();은 다형성 개념이다. 리턴 타입을 받는 형이 runnable이다
	Runnable getRunnable(int i){

		int num = 100;
		
		class MyRunnable implements Runnable{  // myRunnable 자식 클래스 입장. runnable : 부모형, 상위개념

			int localNum = 10;
				
			@Override
			public void run() {
				//num = 200;   //에러 남. 지역변수는 상수로 바뀜
				//i = 100;     //에러 남. 매개 변수 역시 지역변수처럼 상수로 바뀜
				System.out.println("i =" + i); 
				System.out.println("num = " +num);  
				System.out.println("localNum = " +localNum);
					
				System.out.println("outNum = " + outNum + "(외부 클래스 인스턴스 변수)");
				System.out.println("Outter.sNum = " + Outer.sNum + "(외부 클래스 정적 변수)");
				}
			}
		 return new MyRunnable(); // 리턴 타입이 new MyRunnable(); -> 사실은 Runnable을 구현해서 상위개념이 있다.
	}
}

public class LocalInnerTest {

	public static void main(String[] args) {

		Outer out = new Outer();
		Runnable runner = out.getRunnable(10);
		runner.run();
	}
}
