package polymorphism;

import java.util.ArrayList;

class Animal{
	public void move()
	{
		System.out.println("동물이 움직입니다.");
	}
}

class Human extends Animal{
	public void move()
	{
		System.out.println("사람이 두 발로 걷습니다. ");
	}
	
	public void readBook()
	{
		System.out.println("사람이 책을 읽습니다. ");
	}
}

class Tiger extends Animal{
	public void move()
	{
		System.out.println("호랑이가 네 발로 뜁니다. ");
	}
	
	public void hunting() 
	{
		System.out.println("호랑이가 사냥을 합니다. ");
	}
}

class Eagle extends Animal{
	public void move()
	{
		System.out.println("독수리가 하늘을 납니다 ");
	}
	
	public void readBook() 
	{
		System.out.print("독수리가 책을 봅니다.");
	}
}


class Danbi extends Animal {
	public void move()
	{
		System.out.println("단비가 길을 걷습니다");
	}
	
	public void readBook()
	{
		System.out.println("단비가 책을 봅니다");
	}
}
public class AnimalTest1 {
	
	// 상속이라는 개념이
	// 재사용성, 중복제거
	// 다형성 -> 재할당을 할 때, 받을 수 있는 매개변수의 범위를 넓히자
	// 한계 : 상속이 한번만. 기능을 다르게 매번 구현을 하려면
	// 자식 클래스에서 구현하고 싶은 기능이 다양함.
	// 하지만 '반드시 이 기능은 꼭 써주세요~' 라는 부분이 있음
	// 강제성 필요할 때 있음
	// 해당 기능을 각 자식 클래스에서 다르게 구현을 유연하게 하기 위해 -> 인터페이스, 추상클래스
	
	
	 public static void main(String[] args) {
		  AnimalTest1 aTest = new AnimalTest1();
		  aTest.moveAnimal(new Human());
		  aTest.moveAnimal(new Tiger());
		  aTest.moveAnimal(new Eagle());
	 }

	 public void moveAnimal(Animal animal) { //매개 변수의 자료형이 상위 클래스
		  animal.move();                     //재정의 된 메서드 호출
		 //받는 매개변수의 형에 포괄적인 부모클래스를 넣으면 하위의 자식 테이블이 다 가질 수 있음
		 //매개변수를 애초에 큰걸 설정하면 기능 구현할 수 있는게 더 많아진다
	 }   

}



