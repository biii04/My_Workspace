package witharraylist;

public class VVIPCustomer extends Customer{

	private int agentID;
	double saleRatio;
	
	public VVIPCustomer(int customerID, String customerName, int agentID){
		super(customerID, customerName);
	
		customerGrade = "VVIP";
		bonusRatio = 0.15;
		saleRatio = 0.2;
		this.agentID = agentID;
	}
	
	public int calcPrice(int price){
		bonusPoint += price * bonusRatio;
		return price - (int)(price * saleRatio);
	}
	
	public String showCustomerInfo(){
		return super.showCustomerInfo() + " VVIP 담당 상담원 번호는 " + agentID + "입니다";  
	}
	
	public String showcustomerPlus() {
		return super.showCustomerdlqjqPlus() + agentID + "발렛파킹 제공 대상자입니다.";
	}

	public int getAgentID(){
		return agentID;
	}
}
