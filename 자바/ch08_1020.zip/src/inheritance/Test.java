package inheritance;

public class Test {

	Test(){
		
		
		Customer c = new Customer();
		c.bonusPoint = 100;
		c.customerID = 10001;
	}
}
