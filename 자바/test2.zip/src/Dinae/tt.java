package Dinae;

 class tt {
	int x = 10;
	int y = 2;
	int z = 2;	

}

	public static void main(String[] args) {

	z=++x/y;
	x*=y+1;
	z=++x+y++;
	System.out.println(x);
	System.out.println(y);
	System.out.println(z);
	}
