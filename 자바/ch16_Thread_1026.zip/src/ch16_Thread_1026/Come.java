package ch16_Thread_1026;

public class Come {
public void come() {
      while(true){
       System.out.println("come");
      }
   } //come() 메소드내에서 무한루프를 돌면서 문자열"come"를 출력
}