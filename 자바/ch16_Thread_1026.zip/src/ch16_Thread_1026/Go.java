package ch16_Thread_1026;

public class Go {
	   public void go() {
	         while(true){
	          System.out.println("go");
	         }
	      }
	  } // go() 메소드내에서 무한루프를 돌면서 문자열"go"를 출력