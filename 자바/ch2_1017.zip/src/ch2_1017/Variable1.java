package ch2_1017;

public class Variable1 {

	public static void main(String[] args) {

		int level;              //정수형 변수 level을 선언
		level = 10;		//level 변수에 10을 대입
		byte b1 = 12;
		System.out.println(level); 
	}

}
