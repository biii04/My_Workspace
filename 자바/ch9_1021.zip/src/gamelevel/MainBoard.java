package gamelevel;

public class MainBoard {

	public static void main(String[] args) {
		
		
		
		//추상클래스 및 다형성 흐름을 간다히 요양
		//player는 이 클래스 안에 추상클래스(부모클래스) playerlevel을 참조형 변수 level 선언
		// has A 관계로 사용
		// player 디폴트 생성자에 기본 beginerlevel 인스턴스가 생성이 됩니다
		// 그리고 각 자식 클래스 3개 있음 beginnerlevel, advancedlevel, superlevel
		// 3개 클래스의 공통점은 자식 클래스라는 것. 그래서 부모가 추상클래스이므로 자식은 상속을 했기 때문에
		// 반드시 부모에서 정의한 추상 메서드를 강제로 구현한다
		//반드시 구현하는 기능은 run, jump, turn, showlevelmessage이며
		// 템플릿 메서드는 final 표기해서 변경 못하게 했고
		// go(템플릿 메서드)는 안에 정의한 순서대로 진행을 합니다.
		// 진행할 때, 호출하는 메서드는 형식 메서드입니다 (가상메서드)
		// 부모에도 있고 자식에도 있고 모두 같은 메서드에 있다면 자식 선택
		
		//다양성 예제 ) 부모클래스(타입) 확인
		// level = new BeginnerLevel(); 사용함

		Player player = new Player();  //beginnerlevel이 아니라 player라고 되어있는 이유
		player.play(1);				   //player에서 level= new BeginnerLevel(); 이렇게 생성이 되어있기때문
		
		AdvancedLevel aLevel = new AdvancedLevel();
		player.upgradeLevel(aLevel);
		player.play(2);
		
		SuperLevel sLevel = new SuperLevel();
		player.upgradeLevel(sLevel);
		player.play(3);
		
	}
}
