/*
 * © 2022 Deviant Studio
 */

package ds.tetris.di

import org.koin.core.module.Module
import org.koin.dsl.module

actual val platformModule: Module = module {
}