package ds.tetris.util

actual val platform: Platform = Platform.DESKTOP