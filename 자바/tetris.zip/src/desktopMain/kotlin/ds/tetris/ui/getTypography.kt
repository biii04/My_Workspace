package ds.tetris.ui

import androidx.compose.material.Typography

actual suspend fun platformTypography(): Typography = Typography()