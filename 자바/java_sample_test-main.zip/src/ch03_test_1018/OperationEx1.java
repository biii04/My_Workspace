package ch03_test_1018;

public class OperationEx1 {
	public static void main(String[] args) {

		int mathScore = 90;
		int engSccore = 70;
		
		int totalScore = mathScore + engSccore;
		System.out.println(totalScore);
		
		double avgScore = totalScore / 2.0;
		System.out.println(avgScore);
	}
}
