package ch06_staticex_1019;

public class StudentTest5 {

	public static void main(String[] args) {

		System.out.println(Student2.getSerialNum());
	}
}
