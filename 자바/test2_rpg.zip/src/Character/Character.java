package Character;

public class Character {

	public String name;
	public int hp;
	public int mp;
	public int level;
}
