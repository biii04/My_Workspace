package array;

import java.util.ArrayList; 

//다른 클래스를 이용하기 위해서 import를 사용하고 
//자동 임포트 단축키는 crtl + shift + o를 사용한다.

public class ArrayListTest {

	public static void main(String[] args) {

		ArrayList<Book> library = new ArrayList<Book>();  //Arraylist 선언
		// Object 클래스는 최고 상위 클래스. 이거 위는 없음
		// 클래스를 찾아가다가 그 끝은 여기 Object 클래스
		// Object 클래스에서 없으면 없다.

		
		library.add( new Book("태백산맥", "조정래") );
		library.add( new Book("데미안", "헤르만 헤세") );
		library.add( new Book("어떻게 살 것인가", "유시민") );
		library.add( new Book("토지", "박경리") );
		library.add( new Book("어린왕자", "생텍쥐페리") );
		library.add( new Book("백설공주에게 죽음을","넬레노이하우스") );
		library.add( new Book("개미","베르나르베르베르"));
		
		for(int i=0; i<library.size(); i++){
	
			Book book = library.get(i);
			book.showBookInfo();
		}
		
		System.out.println();
		System.out.println("=== 향상된 for문 사용 ===");
		for(Book book : library){
			book.showBookInfo();
		}
	}
}
