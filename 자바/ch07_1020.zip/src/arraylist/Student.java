package arraylist;

import java.util.ArrayList;

public class Student {
	
	// 인스턴스 변수
	int studentID;
	String studentName;
	
	// 제너릭으로 유효성 검사처럼 데이터 형이 Subject라는 형으로만 들어갈 수 있다.
	// 이 ArrayList의 원소 타입
	// Subject 타입의 참조형 변수(인스턴스)
	ArrayList<Subject> subjectList;  //선언만 하고 초기화는 안함

	public Student(int studentID, String studentName){
		this.studentID = studentID;
		this.studentName = studentName;
		
		subjectList = new ArrayList<Subject>(); //학생이라는 수납 도구 안에는 3개의 변수가 존재
	}
	
	public void addSubject(String name, int score){
		Subject subject = new Subject();
		
		subject.setName(name);
		subject.setScorePoint(score);
		subjectList.add(subject);
	}
	
	public void showStudentInfo()
	{
		int total = 0;
		
		for(Subject s : subjectList){
			
			total += s.getScorePoint();
			System.out.println("학생 " + studentName + "의 " + s.getName() + " 과목 성적은 " + 
			        s.getScorePoint() + "입니다.");
		}
			
		System.out.println("학생 " + studentName + "의 총점은 " + total + " 입니다.");
	}
}
