package staticex;

public class StudentTest5 {

	public static void main(String[] args) {

		System.out.println(Student2.getSerialNum());
	}
}
