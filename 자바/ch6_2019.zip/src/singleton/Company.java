package singleton;

//import staticex.company;

public class Company {

	private static Company instance = new Company();
	String address;
	String name;
	int age;
	
	private Company(){}
	
	public static Company getInstance(){
		if(instance == null){
			instance = new Company();
		}
		return instance;
	}
}

/*
company 클래스 타입(return type) getInstance는 method 

return instance 에서 instance는 company 타입 값이 없으면 생성자 만들고 있으면 그대로 쓴다 
		좋은점은? 외부에서 이 매소드가 아니면 접근 불가 - 어떤 자원에 접근하는 용도로만 쓴다
*/