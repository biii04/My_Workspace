package ch6_2019;

public class Animal {

	String name;
	int age;
	
	public Animal() {}
	
	public Animal(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	
	public String getName() {  //클래스에 설정된 이름 설정
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public void move() {
		System.out.println("이동하기.");
	}

}
