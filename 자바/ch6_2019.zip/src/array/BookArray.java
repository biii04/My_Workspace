//수행하는 곳
package array;

public class BookArray {

	public static void main(String[] args) {
		Book[] library = new Book[5];  //배열타입은 book형. book타입의 인스턴스가 들어감 []안에 
										//library란 참조형 변수는 book타입이 들어감
		
		for(int i=0; i<library.length; i++){
			System.out.println(library[i]);  //i에 아무 값도 안넣으면 null로 출력
		}		
	}
}
