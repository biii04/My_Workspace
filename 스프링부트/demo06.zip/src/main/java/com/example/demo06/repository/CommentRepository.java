package com.example.demo06.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.example.demo06.model.Comment;

public interface CommentRepository extends JpaRepository<Comment, Long> {
	
	//댓글추가
	@Modifying
	@Query(value = "insert into tbl_Comment06(content, regdate, bnum, user_id) values(?1,now(),?2,?3)",
			nativeQuery=true)
	public void insert(String content, Long bnum, Long user_id);
	
	//댓글리스트
	//JPQL(Java Persistence Query Langauge:엔터티 갤체를 중심)
	//@Query("SELECT SC FROM tbl_Comment06 SC WHERE bnum=?1")  //BOARD.java_eager쓸 때 사용
	@Query("select sc from tbl_Comment06 sc join fetch sc.board where bnum=?1") //board.java_lazy일 대 사용
	public List<Comment> findByBnum(Long bnum);


	
}
