package com.example.demo06.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo06.model.Board;
import com.example.demo06.model.User;
import com.example.demo06.repository.BoardRepository;

@Transactional(readOnly=true)
@Service
public class BoardService {
	@Autowired
	private BoardRepository bRepository;
	
	@Transactional
	public void insert(Board board, User user) {
		board.setUser(user);
		bRepository.save(board);
	}
	
	//페이징 없이 전체보기
	public List<Board> findAll(){
		return bRepository.findAll();
	}
	
	//페이징 포함 전체보기
	public Page<Board> findAll(Pageable pageable){
		return bRepository.findAll(pageable);
	}
	
	//페이징 검색 전체보기
	public Page<Board> findAll(String field, String word, Pageable pageable) {
		Page<Board> lists = bRepository.findAll(pageable);
		if(field.equals("title")) {
			lists=bRepository.findByTitleContaining(word,pageable);
		}else if(field.equals("content")){
			lists = bRepository.findByContentContaining(word, pageable);
		}
		return lists;
	}
	
	public Long count(String field, String word) {
		Long count = bRepository.count();
		if(field.equals("title")) {
			count=bRepository.cntTitleSearch(word);
		}else if(field.equals("content")){
			count = bRepository.cntContentSearch(word);
		}
		return count;
	}
	
	//댓글개수
	/*
	 * public Long count() { return bRepository.count(); }
	 */
	
	@Transactional
	public Board findById(Long num) {
		Board board = bRepository.findById(num).get();
		board.setHitcount(board.getHitcount()+1);
		return board;
	}
	
	@Transactional
	public void delete(Long num) {
		bRepository.deleteById(num);
	}
	
	//수정 =>더티체킹
	@Transactional
	public void update(Board board) {
		Board b = bRepository.findById(board.getNum()).get();
		b.setTitle(board.getTitle());
		b.setContent(board.getContent());
	}

}
