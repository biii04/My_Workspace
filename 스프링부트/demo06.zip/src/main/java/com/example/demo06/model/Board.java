package com.example.demo06.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@Entity(name="tbl_board06")
public class Board {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long num;
	private String title;
	private String content;
	
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date regdate;
	
	@OneToMany(mappedBy = "board", cascade = CascadeType.REMOVE)
	@JsonIgnoreProperties("board") //무한참조 방지
	private List<Comment> comments;
	
	@ManyToOne(fetch = FetchType.LAZY)  //join을 미뤄서 실행 시점에 가져오겠다는 뜻
	//@ManyToOne(fetch = FetchType.EAGER) //쓸데없이 빨리 조인되기 때문에 성능 저하됨
	@JoinColumn(name="user_id")
	@JsonIgnore
	private User user;
	
	private Long hitcount;
	private Long replyCnt;
	
	@PrePersist
	public void prePerist() {
		this.hitcount = this.hitcount == null?0: this.hitcount;
		this.replyCnt = this.replyCnt == null?0: this.replyCnt;
	}
}
