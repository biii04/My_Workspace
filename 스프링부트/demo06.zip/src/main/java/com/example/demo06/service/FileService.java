package com.example.demo06.service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo06.model.FileBoard;
import com.example.demo06.repository.FileRepository;

@Service
public class FileService {
	@Autowired
	private FileRepository fRepository;
	
	public void fileInsert(FileBoard fboard, String uploadFolder) {
		UUID uuid = UUID.randomUUID();  //create random ID
		MultipartFile f = fboard.getUpload(); //upload는 multipart형
		String uploadFileName="";
		if(!f.isEmpty()) { //select file
			uploadFileName=uuid.toString()+"_"+f.getOriginalFilename();
			File saveFile = new File(uploadFolder, uploadFileName);
			
			try {
				f.transferTo(saveFile);  //file upload 
				fboard.setFileimage(uploadFileName);
			} catch (IllegalStateException|IOException e) {
				e.printStackTrace();
			}
		}
		fRepository.save(fboard);
	}

	public List<FileBoard> fileList() {
		return fRepository.findAll();
	}

	public void fileInsert2(FileBoard fboard) {
		UUID uuid = UUID.randomUUID();  //create random ID
		MultipartFile f = fboard.getUpload(); //upload는 multipart형
		String uploadFileName="";
		if(!f.isEmpty()) { //select file
			uploadFileName=uuid.toString()+"_"+f.getOriginalFilename();
			File saveFile = new File(uploadFileName);
			
			try {
				f.transferTo(saveFile);  //file upload 
				fboard.setFileimage(uploadFileName);
			} catch (IllegalStateException|IOException e) {
				e.printStackTrace();
			}
		}
		fRepository.save(fboard);
		
	}
	
	
}
