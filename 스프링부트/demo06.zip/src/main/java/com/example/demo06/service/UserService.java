package com.example.demo06.service;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo06.model.User;
import com.example.demo06.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {
	private final BCryptPasswordEncoder encoder;
	
	private final UserRepository uRepository;
	
	//회원가입
	public void register(User user) {
		//비밀번호 암호화 시키고 추가
		String rawPassword = user.getPassword();
		String encPassword = encoder.encode(rawPassword);
		user.setPassword(encPassword);
		user.setRole("ROLE_USER");
		uRepository.save(user);
	}
	

	
}
