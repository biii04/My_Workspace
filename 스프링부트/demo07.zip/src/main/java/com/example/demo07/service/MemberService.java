package com.example.demo07.service;

import java.util.List;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo07.model.Member;
import com.example.demo07.repository.MemberRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MemberService {
	private final BCryptPasswordEncoder encoder;
	
	private final MemberRepository mRepository;
	
	//회원가입
	public void join(Member member) {
		//비밀번호 암호화 시키고 추가
		String rawPassword = member.getPassword();
		String encPassword = encoder.encode(rawPassword);
		member.setPassword(encPassword);
		member.setRole("ROLE_USER");
		mRepository.save(member);
	}
	
	public List<Member> list(){
		return mRepository.findAll();
	}
	
	public Long count() {
		return mRepository.count();
	}
	
	public Member detail(Long id) {
		return mRepository.findById(id).get();
	}
	
	//수정(더티체킹)
	@Transactional
	public void update(Member member) {
		Member m = mRepository.findById(member.getId()).get();
		 m.setEmail(member.getEmail());
	}
	
	public void delete(Long id) {
		mRepository.deleteById(id);
	}
	
}
