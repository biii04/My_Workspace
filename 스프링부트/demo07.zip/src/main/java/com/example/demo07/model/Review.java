package com.example.demo07.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
public class Review {
	
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@JoinColumn(name="hotel_id") //외래키가 review에 있음(주인 역할, hotel은 바라만 보는 역할)
	@ManyToOne  //N:1
	private Hotel hotel;
	private int rate;
	private String comment;
	private Date ratingDate;
}
