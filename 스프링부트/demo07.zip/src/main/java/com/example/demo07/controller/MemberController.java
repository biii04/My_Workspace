package com.example.demo07.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo07.model.Member;
import com.example.demo07.repository.MemberRepository;
import com.example.demo07.service.MemberService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class MemberController {
	
	private final MemberService mservice;
	private final MemberRepository mrepository;
	
	@GetMapping("/")
	public String home() {
		return "redirect:/list";
	}
	
	@GetMapping("/login")
	public String login() {
		return "/member/login";
	}
	
	
	@GetMapping("/join")
	public String join() {
		return "/member/join";
	}
	
	@PostMapping("/join")
	@ResponseBody
	public String join(@RequestBody Member member) {
		if(mrepository.findByUsername(member.getUsername()) != null) {
			return "fail";
		}
		mservice.join(member);
		return "success";
	}
	
	@GetMapping("/list")
	public String list(Model model) {
		System.out.println("list");
		model.addAttribute("member", mservice.list());
		model.addAttribute("count", mservice.count());
		return "/member/list";
	}
	
	@GetMapping("/detail/{id}")
	public String detail(@PathVariable Long id, Model model) {
		model.addAttribute("member",mservice.detail(id));
		return "/member/detail";
	}
	
	//수정
	  @PutMapping("/update")
	  @ResponseBody
	  public String update(@RequestBody Member member, HttpSession session) {
		  mservice.update(member);
		  session.invalidate();
		  return  "success";
	  }
	  
	  @DeleteMapping("/delete/{id}")
	  @ResponseBody
	  public String delete(@PathVariable Long id, HttpSession session) {
		  mservice.delete(id);
		  session.invalidate(); //세션 줬다뺐기
		  return "success";
	  }

	  
	
}
