package com.example.demo07.model;

public enum Grade {
	STAR1, STAR2, STAR3, STAR4, STAR5
}
