package com.example.demo07.config.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo07.model.Member;
import com.example.demo07.repository.MemberRepository;

@Service
public class PrincipalDetailService implements UserDetailsService {
	@Autowired
	private MemberRepository mRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		System.out.println("loadUserByUsername");
		Member user = mRepository.findByUsername(username);
		if(user == null) 
			 return null;
		//회원이라면 시큐리티가 적용된 User 리턴
		PrincipalDetails puser = new PrincipalDetails(user);
		System.out.println("puser:" + puser);
		return puser;
	}

}
