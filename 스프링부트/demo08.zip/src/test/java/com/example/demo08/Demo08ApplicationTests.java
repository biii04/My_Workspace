package com.example.demo08;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo08ApplicationTests {

	@Test
	void contextLoads() {
	}

}
