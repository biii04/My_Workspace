package com.example.demo08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo08Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo08Application.class, args);
	}

}
