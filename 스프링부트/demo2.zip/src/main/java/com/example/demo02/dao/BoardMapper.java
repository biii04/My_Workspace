package com.example.demo02.dao;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.example.demo02.dto.BoardDTO;

@Mapper
public interface BoardMapper {
	
	//추가
	@Insert("insert into board(title, writer, content)values(#{title},#{writer},#{content})")
	public void insert(BoardDTO board);
	
	//전체보기
	@Select("select * from board")    //xml파일에 작성
	public List<BoardDTO> list();
	
	//상세보기
	@Select("select * from board where num=#{num}")
	public BoardDTO view(int num);
	
	//개수
	@Select("select count(*) from board")
	public int bcount(int num);
	
	//수정
	@Update("update board set title=#{title}, content=#{content}, regdate=now() where num=#{num}")
	public void update(BoardDTO board);
	
	//updateReplyCnt
	@Update("update board set replycnt= replycnt+#{amount} where num=#{bnum}")
	public void updateReplyCnt(@Param("bnum") int  bnum, @Param("amount") int amount);
}
