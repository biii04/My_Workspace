package com.example.demo05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
