package com.example.demo05.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class MemberShipCard {
	@Id
	private String cardNumber;
	@JoinColumn(name="user_email")  //유저를 통해 카드 조회가능
	@OneToOne  //1:1관계의 양방향
	private User owner;  //객체지향적인 표현(private String email)을 쓰는것 대신
	private Date expiryDate;
	private boolean enabled;
}
