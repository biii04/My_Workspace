package com.example.demo05.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class tbl_order {
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long orderid;
	
	private String note;
	private String ordername;
	private int price;
	
	@JoinColumn(name = "user_id") //객체지향. 외래키잡는중(joincolumn)
	@ManyToOne(fetch=FetchType.LAZY)  //실행시점에 실행시키고싶은것.(시작하자마자 실행시키는게 디폴트값)
	private tbl_user user;
}
