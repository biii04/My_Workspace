package com.example.demo05.model;

import java.util.List;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Hotel {
	
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)  //자동 등록
	private Long id;
	
	private String name;
	
	@Enumerated(EnumType.STRING)
	private Grade grade;
	
	@Embedded //포함시킴
	private Address address;
	
	@OneToMany(mappedBy = "hotel")  //1:N
	private List<Review> reviews;  //호텔 하나에 여러개의 리뷰가 달리니 list형으로 만들어주기
}
