package com.example.demo06.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo06.model.User;
import com.example.demo06.repository.UserRepository;
import com.example.demo06.service.UserService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor //autowired와 같은 역할을 함
public class HomeController {
	private final UserService uService;
	private final UserRepository uRepository;
	
	  @GetMapping("/")
	  public String home() {
		  return "test/home";
	  }
	  
	  @GetMapping("/login")
	  public String login() {
		  return "/user/login";
	  }
	  
	  //회원가입
	  @GetMapping("/join")
	  public String join() {
		  return "/user/join";
	  }
	  
	  @GetMapping("/userDetail")
	  public void userDetail() {
		  
	  }
	  
	  @PostMapping("/userDetail")
	  public String userDetail(HttpSession session, User user) {
		  session.setAttribute("user", user);
		  return "/user/userDetail";
	  }
	  
	  //회원가입 폼
	  @PostMapping("register")
	  @ResponseBody
	  public String register(@RequestBody User user) {
		  //username있으면 있으면 fail리턴
		  if(uRepository.findByUsername(user.getUsername()) != null) {
			  return "fail";
		  }
	      uService.register(user);
	      return "success";
	  }
	  
}
