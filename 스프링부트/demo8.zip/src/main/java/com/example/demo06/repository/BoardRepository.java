package com.example.demo06.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo06.model.Board;
import com.example.demo06.model.Comment;

public interface BoardRepository extends JpaRepository<Board, Long>{

	public Page<Board> findByTitleContaining(String word, Pageable pageable);

	public Page<Board> findByContentContaining(String word, Pageable pageable);

	//제목 검색 개수
	@Query(value = "select count(*) from tbl_board06 where title like CONCAT('%',:word,'%')",
			nativeQuery = true)
	public Long cntTitleSearch(String word);

	@Query(value = "select count(*) from tbl_board06 where content like CONCAT('%',:word,'%')",
			nativeQuery = true)
	public Long cntContentSearch(String word);

	
	
	//만약 service에서 delete이름을 바꾸고 싶으면 여기에 기재 후 service에 적기. 
	//public void deleteByNum(Long num);
}
