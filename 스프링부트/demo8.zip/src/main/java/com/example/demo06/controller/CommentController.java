package com.example.demo06.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo06.config.auth.PrincipalDetails;
import com.example.demo06.model.Board;
import com.example.demo06.model.Comment;
import com.example.demo06.service.CommentService;

@RestController
@RequestMapping("/reply/*")
public class CommentController {
	@Autowired
	private CommentService cService;
	
	//댓글추가 방법 1
	@PostMapping("insert/{num}")
	public ResponseEntity<String> commentInsert(@PathVariable Long num, @RequestBody Comment comment,
			@AuthenticationPrincipal PrincipalDetails principal) {  //username받아오는법2
		Board b = new Board();
		b.setNum(num);  //bnum
		comment.setBoard(b);  //이 세줄 : bnum을 가지기 위함(이거 없으면 bnum값 안들어감)
		
		/*
		 * //username 받아오는법 1
		 * PrincipalDetails p = (PrincipalDetails)
		 * SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		 * comment.setUser(p.getUser()); //username sql에 출력
		 */		
		comment.setUser(principal.getUser());  //222222 SQL에 출력
		cService.insert(comment);
		return new ResponseEntity<String>("success",HttpStatus.OK) ; //받아와야할 값 + 상태값
	}
	
	@GetMapping("list/{num}")
	public List<Comment> list(@PathVariable Long num) {
		List<Comment> clist=cService.list(num);
		return clist;
	}
	
	@DeleteMapping("delete/{cnum}")
	public Long delete(@PathVariable Long cnum) {
		cService.delete(cnum);
		return cnum;
	}
}
