package com.example.demo06;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo06ApplicationTests {

	@Test
	void contextLoads() {
	}

}
